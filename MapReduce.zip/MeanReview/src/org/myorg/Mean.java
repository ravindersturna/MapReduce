package org.myorg;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.fs.FileSystem;

public class Mean 
{
	public static void main(String[] args) throws Exception
	{
		Configuration conf = new Configuration();
		//Checks the length of parameters passed
		if (args.length != 3)
		{
			System.err.println("Error in Input");
			System.exit(-1);
		}
		//job from Job class will be used to assign all MapReduce jobs.
		Job job = new Job(conf, "Mean");
		//specifying the driver class in the Jar file
		job.setJarByClass(Mean.class);
		//setting the input and output paths for the job
		FileInputFormat.addInputPath(job, new Path(args[1]));
		FileOutputFormat.setOutputPath(job, new Path(args[2]));
		//Setting the mapper and mapper for the job
		job.setMapperClass(MeanMapper.class);
		job.setReducerClass(MeanReducer.class);
		//Setting the Key and Value class
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(DoubleWritable.class);

      		// Delete output if exists
	   	FileSystem hdfs = FileSystem.get(conf);
        		Path outputDir = new Path(args[2]);
		if (hdfs.exists(outputDir))
          	    hdfs.delete(outputDir, true);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
