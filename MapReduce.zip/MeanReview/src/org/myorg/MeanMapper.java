package org.myorg;

import java.io.IOException;
//import java.util.regex.Pattern;
//import java.util.regex.Matcher;
//import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.io.Text;

public class MeanMapper extends Mapper<LongWritable, Text, IntWritable, DoubleWritable>
{
	private final static DoubleWritable ratingWritable = new DoubleWritable(0);
	private IntWritable recipeID = new IntWritable();
	
	@Override
	public void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException
	{
		//Split the values based on "," and store in line variable
		String[] line = value.toString().split(",");
		//Pass the index of RecipeID to set the RecipeId value and convert to Integer
		String ID = line[0];
		recipeID.set(Integer.parseInt(ID));
		//Pass the index of Rating and store in the variable
		double rating = Double.parseDouble(line[1]);
		ratingWritable.set(rating);
		//Emit the RecipeId and Ratings for RecipeId
		context.write(recipeID, ratingWritable);
	}
}
