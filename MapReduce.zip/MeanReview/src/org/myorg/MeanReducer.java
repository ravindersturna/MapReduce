package org.myorg;

import java.io.IOException;
//import java.util.ArrayList;
//import java.util.Collections;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
//import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MeanReducer extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable>
{
	 @Override
	 public void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) 
			 throws IOException, InterruptedException
	 {
		 //Initialize the SumOfRating as 0
		 double SumOfRating = 0.0;
		 //Initialize the count as 0
		 int count=0;
		 //Loop through all the values
		 for(DoubleWritable value : values)
		 {
			 //Store the count and sum of all the ratings for a recipe
			 count = count + 1;
			 SumOfRating = SumOfRating + value.get();
		 }
		 //Divide the sum by count to get the mean.
		 double mean = SumOfRating/count;
		 //emit the maximum values for each RecipeId
		 context.write(key, new DoubleWritable(mean));
	 }
}
