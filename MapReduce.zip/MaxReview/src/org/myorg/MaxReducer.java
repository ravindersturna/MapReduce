package org.myorg;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MaxReducer extends Reducer<IntWritable, DoubleWritable, IntWritable, DoubleWritable>
{
	@Override
	public void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) 
			throws IOException, InterruptedException
	{
		double minValue = 0;
		//Loop through all the values
		for(DoubleWritable value : values)
		{
			//Store the maximum Rating for each RecipeId
			minValue = Math.max(minValue, value.get());
		}
		//emit the maximum values for each RecipeId
		context.write(key, new DoubleWritable(minValue));
	}
}
