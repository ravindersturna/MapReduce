package my.org;
import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class ReviewCount extends Mapper<LongWritable, Text, IntWritable, IntWritable>
{
	private final static IntWritable one = new IntWritable(1);
	// Assigns 1 to each reviewed RecipeId
	IntWritable recipe = new IntWritable();
	
	@Override
	public void map(LongWritable key, Text value, Context context)
	throws IOException, InterruptedException
	{
		//Fetch all the records one-by-one
		String line = value.toString();
		StringTokenizer tokenizer = new StringTokenizer(line);
		
		//The while loop will go through all the Reviews for RecipeId in the input data file 
        //and emit key-value pair for each word
		while(tokenizer.hasMoreTokens())
		{
			recipe.set(Integer.parseInt(tokenizer.nextToken()));
			//Add the pair (RecipeId, 1) to the context and emit it
			context.write(recipe, one);
		}
	}
}

