package my.org;
import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Reducer;

public class ReviewCountReducer extends 
Reducer<IntWritable, IntWritable, IntWritable, IntWritable>
{
	@Override
	public void reduce(IntWritable key, Iterable<IntWritable> values, Context context)
	throws IOException, InterruptedException
	{
		int sum = 0;
		for(IntWritable value : values)
		{
			//calculate the sum of all values for each RecioeId
			sum = sum+value.get();
		}
		//emit the sum of all values for each RecipeId
		context.write(key, new IntWritable(sum));
	}
}

