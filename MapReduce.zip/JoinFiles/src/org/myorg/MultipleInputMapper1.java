package org.myorg;
import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MultipleInputMapper1 extends Mapper<LongWritable,Text,LongWritable,Text>
{
	private static String separator;
	private static String commonSeparator;
	private static String File_Tag = "RECIPE";
	
	public void setup(Context context)
	{
		Configuration configuration = context.getConfiguration();
		
		//Retrieving the file separator from context for file1.
		separator = ",";
		
		//Retrieving the file separator from context for writing the data to reducer.
		commonSeparator=",";
	}
	
	@Override
	public void map(LongWritable rowKey, Text value, Context context) 
			throws IOException, InterruptedException
	{
		//Split values based on ","
		String[] values = value.toString().split(separator);
		StringBuilder stringBuilder = new StringBuilder();
		//Loop through all the values
		for(int index=0; index<values.length;index++)
		{
			//Add the common separator to each value
			stringBuilder.append(values[index]+commonSeparator);
		}
		if(values[0] != null && !"NULL".equalsIgnoreCase(values[0]))
		{
			//Emit the values with File_Tag, Common separator and values
			context.write(new LongWritable(Long.parseLong(values[0])),
					new Text(File_Tag+commonSeparator+stringBuilder.toString()));
		}
	}
}
