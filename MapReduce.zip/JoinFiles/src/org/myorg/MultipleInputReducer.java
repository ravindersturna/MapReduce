package org.myorg;

import java.io.IOException;
import java.util.Arrays;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MultipleInputReducer extends Reducer<LongWritable, Text, LongWritable, Text> 
{
	private static String commonSeparator;
	public void setup(Context context)
	{
		Configuration configuration = context.getConfiguration();
		//Retrieving the common file separator from context for output file.
		commonSeparator=",";
	}
	@Override
	public void reduce(LongWritable key, Iterable<Text>
	textValues, Context context) throws IOException, InterruptedException
	{
		StringBuilder stringBuilder = new StringBuilder();
		String[] firstFileValues=null, secondFileValues=null;
		String[] stringValues;
		for (Text textValue : textValues)
		{
			//Split values based on ","
			stringValues = textValue.toString().split(commonSeparator);
			//Check for the File_Tag
			if("RECIPE".equalsIgnoreCase(stringValues[0]))
			{
				//Take values from first input file
				firstFileValues=Arrays.copyOf(stringValues, stringValues.length);
			}
			//Check for File_Tag
			if("REVIEW".equalsIgnoreCase(stringValues[0]))
			{
				//Take values from second input file
				secondFileValues = Arrays.copyOf(stringValues, stringValues.length);
			}
		}
		if(firstFileValues != null)
		{
			for(int index=0;index<firstFileValues.length;index++)
			{
				//Append values with ","
				stringBuilder.append(firstFileValues[index]+commonSeparator);
			}
		}
		if(secondFileValues != null)
		{
			for(int index=0;index<secondFileValues.length;index++)
			{
				//Append values with ","
				stringBuilder.append(secondFileValues[index]+commonSeparator);
			}
		}
		//Emit the joined values
		context.write(key, new Text(stringBuilder.toString()));
	}
		
}
