package org.myorg;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class MinReducer extends Reducer<IntWritable, DoubleWritable,
IntWritable, DoubleWritable>
{
	@Override
	public void reduce(IntWritable key, Iterable<DoubleWritable> values, Context context) 
			throws IOException, InterruptedException
	{
		//Store the initial value as 5 as that is the max rating
		//Math.min() will compare the two values and store the minimum in minValue
		double minValue=5;
		//Loop through all the values
		for(DoubleWritable value : values)
		{
			//Store the minimum Rating for each RecipeId
			minValue = Math.min(minValue, value.get());
		}
		//emit the minimum values for each RecipeId
		context.write(key, new DoubleWritable(minValue));
	}
}
