package org.myorg;

import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;



public class MinMapper extends Mapper<LongWritable, Text, IntWritable, DoubleWritable>
{
	private final static DoubleWritable ratingWritable = new DoubleWritable(0);
	private IntWritable recipeID = new  IntWritable();
	
	@Override
	public void map(LongWritable key, Text value, Context context) 
			throws IOException, InterruptedException
	{
		//Split the values based on "," and store in line variable
		String[] line = value.toString().split(",");
		//Pass the index of RecipeID to set the RecipeId value and convert to Integer
		recipeID.set(Integer.parseInt(line[0]));
		//Pass the index of Rating and store in the variable
		double rating = Double.parseDouble(line[1]);
		ratingWritable.set(rating);
		context.write(recipeID, ratingWritable);
	}
	
}
